#ifndef UTILS_H
#define UTILS_H
#define TRUE 1
#define FALSE 0
#define boolean int
#define ERRO_GENERICO -4000
#include <stdio.h>
char *readLine ();
#endif
